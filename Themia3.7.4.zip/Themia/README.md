# Themia-for-TE

针对typecho优化的Themia模板

下载后上传到typecho模板目录解压，将解压后的文件夹重命名为Themia，即可使用

模板特色：

无需插件的文章置顶功能，

无需插件显示文章浏览次数(有cookie验证)，

无需插件大赏跨屏浏览功能，

无需插件的缩略图功能，

版权保护功能，界面语言中/英切换，文章内容简/繁翻译，

模板样式的自定义功能，超强的自定义字段功能，利用QQ空间，新浪等api的分享功能

详细介绍看下面的链接，github我比较迷茫所以有问题也去下面的链接评论

http://qqdie.com/archives/with-the-help-of-themia-subject-to-update-the-manual/

历史更新记录http://forum.typecho.org/viewtopic.php?f=5&t=9184
